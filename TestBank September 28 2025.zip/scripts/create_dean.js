import mongoose from "mongoose";
import bcrypt from "bcrypt";

const adminSchema = new mongoose.Schema({
  lastName: { type: String, required: true },
  firstName: { type: String, required: true },
  middleName: { type: String, required: true },
  contactNumber: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  employeeID: { type: String, required: true, unique: true },
  department: { type: String, required: true },
  designation: { type: String, required: true, enum: ["Professor", "Dean"] },
  employmentStatus: { type: String, required: true, enum: ["Full-time", "Part-time", "Contractual"] },
  password: { type: String, required: true },
  role: { type: String, required: true, enum: ["Professor", "Dean"] },
  accountStatus: { type: String, required: true, default: "Active", enum: ["Active", "Inactive", "Suspended"] },
  createdBy: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
  resetToken: String,
  resetTokenExpiry: Date
});

const Admin = mongoose.model("Admin", adminSchema);

const createDean = async () => {
  await mongoose.connect("mongodb://127.0.0.1:27017/yourDatabaseName");

  const hashedPassword = await bcrypt.hash("dean123", 10);

  const dean = new Admin({
    lastName: "Presentacion",
    firstName: "Jay-Pee",
    middleName: "Macaraeg",
    contactNumber: "N/A",
    email: "qwerty001522@gmail.com",
    employeeID: "DTest",
    department: "N/A",
    designation: "Dean",
    employmentStatus: "Full-time",
    password: hashedPassword,
    role: "Dean",
    createdBy: "System"
  });

  await dean.save();
  console.log("Dean account created successfully.");
  await mongoose.disconnect();
};

createDean();
