// scripts/seedStudentData.js
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Student from '../../models/Student.js';
import Section from '../../models/Section.js';

dotenv.config();

// Connect to MongoDB
const connectDB = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI);
        console.log('✅ MongoDB connected for student seeding');
    } catch (error) {
        console.error('❌ MongoDB connection error:', error);
        process.exit(1);
    }
};

// Generate dummy student data
const generateStudentData = async () => {
    try {
        console.log('🎯 Starting student data generation...');
        
        // Get existing sections to enroll students in
        const existingSections = await Section.find({});
        
        if (existingSections.length === 0) {
            console.log('❌ No sections found. Please create sections first.');
            return;
        }

        console.log(`📋 Found ${existingSections.length} existing sections`);

        // Dummy student data - will be added to Student collection AND enrolled in sections
        const dummyStudents = [
            // BSIT Students
            {
                studentID: "2024-0001",
                firstName: "Juan",
                lastName: "Dela Cruz",
                middleName: "Santos",
                email: "juan.delacruz@student.edu",
                password: "$2a$12$rypunVcKVCq.aomFTeBGFOD3E9sX62.SoSnLAYxY1Xt/AUg3tORqq", // "password123"
                course: "BSIT",
                section: "BSIT2-A",
                yearLevel: "2nd Year",
                campus: "Main"
            },
            {
                studentID: "2024-0002",
                firstName: "Maria",
                lastName: "Santos",
                middleName: "Reyes",
                email: "maria.santos@student.edu",
                password: "$2a$12$rypunVcKVCq.aomFTeBGFOD3E9sX62.SoSnLAYxY1Xt/AUg3tORqq",
                course: "BSIT",
                section: "BSIT2-A",
                yearLevel: "2nd Year",
                campus: "Main"
            },
            {
                studentID: "2024-0003",
                firstName: "Pedro",
                lastName: "Reyes",
                middleName: "Garcia",
                email: "pedro.reyes@student.edu",
                password: "$2a$12$rypunVcKVCq.aomFTeBGFOD3E9sX62.SoSnLAYxY1Xt/AUg3tORqq",
                course: "BSIT",
                section: "BSIT2-B",
                yearLevel: "2nd Year",
                campus: "Main"
            },
            {
                studentID: "2024-0004",
                firstName: "Ana",
                lastName: "Garcia",
                middleName: "Lopez",
                email: "ana.garcia@student.edu",
                password: "$2a$12$rypunVcKVCq.aomFTeBGFOD3E9sX62.SoSnLAYxY1Xt/AUg3tORqq",
                course: "BSIT",
                section: "BSIT2-B",
                yearLevel: "2nd Year",
                campus: "Main"
            },

            // BSIS Students
            {
                studentID: "2024-0005",
                firstName: "Miguel",
                lastName: "Tan",
                middleName: "Lim",
                email: "miguel.tan@student.edu",
                password: "$2a$12$rypunVcKVCq.aomFTeBGFOD3E9sX62.SoSnLAYxY1Xt/AUg3tORqq",
                course: "BSIS",
                section: "BSIS3-A",
                yearLevel: "3rd Year",
                campus: "South"
            },
            {
                studentID: "2024-0006",
                firstName: "Sofia",
                lastName: "Lim",
                middleName: "Chen",
                email: "sofia.lim@student.edu",
                password: "$2a$12$rypunVcKVCq.aomFTeBGFOD3E9sX62.SoSnLAYxY1Xt/AUg3tORqq",
                course: "BSIS",
                section: "BSIS3-A",
                yearLevel: "3rd Year",
                campus: "South"
            },

            // BSCS Students
            {
                studentID: "2024-0007",
                firstName: "Luis",
                lastName: "Chen",
                middleName: "Wong",
                email: "luis.chen@student.edu",
                password: "$2a$12$rypunVcKVCq.aomFTeBGFOD3E9sX62.SoSnLAYxY1Xt/AUg3tORqq",
                course: "BSCS",
                section: "BSCS1-A",
                yearLevel: "1st Year",
                campus: "Main"
            },
            {
                studentID: "2024-0008",
                firstName: "Elena",
                lastName: "Wong",
                middleName: "Zhang",
                email: "elena.wong@student.edu",
                password: "$2a$12$rypunVcKVCq.aomFTeBGFOD3E9sX62.SoSnLAYxY1Xt/AUg3tORqq",
                course: "BSCS",
                section: "BSCS1-A",
                yearLevel: "1st Year",
                campus: "Main"
            },
            {
                studentID: "2024-0009",
                firstName: "Carlos",
                lastName: "Zhang",
                middleName: "Liu",
                email: "carlos.zhang@student.edu",
                password: "$2a$12$rypunVcKVCq.aomFTeBGFOD3E9sX62.SoSnLAYxY1Xt/AUg3tORqq",
                course: "BSCS",
                section: "BSCS1-B",
                yearLevel: "1st Year",
                campus: "Main"
            },
            {
                studentID: "2024-0010",
                firstName: "Isabella",
                lastName: "Liu",
                middleName: "Yang",
                email: "isabella.liu@student.edu",
                password: "$2a$12$rypunVcKVCq.aomFTeBGFOD3E9sX62.SoSnLAYxY1Xt/AUg3tORqq",
                course: "BSCS",
                section: "BSCS1-B",
                yearLevel: "1st Year",
                campus: "Main"
            }
        ];

        let createdCount = 0;
        let enrolledCount = 0;

        // Create students in Student collection
        for (const studentData of dummyStudents) {
            try {
                // Check if student already exists
                const existingStudent = await Student.findOne({ 
                    $or: [
                        { studentID: studentData.studentID },
                        { email: studentData.email }
                    ]
                });

                if (!existingStudent) {
                    const student = new Student(studentData);
                    await student.save();
                    createdCount++;
                    console.log(`✅ Created student: ${student.fullName} (${student.studentID})`);

                    // Enroll student in section
                    const section = await Section.findOne({ name: studentData.section });
                    if (section) {
                        // Check if student is already enrolled
                        const isAlreadyEnrolled = section.students.some(s => 
                            s.studentId === studentData.studentID
                        );

                        if (!isAlreadyEnrolled) {
                            section.students.push({
                                id: student._id.toString(),
                                name: student.fullName,
                                studentId: studentData.studentID,
                                course: studentData.course,
                                yearLevel: studentData.yearLevel,
                                campus: studentData.campus
                            });
                            
                            section.updatedAt = new Date();
                            await section.save();
                            enrolledCount++;
                            console.log(`   📚 Enrolled in section: ${section.name}`);
                        } else {
                            console.log(`   ℹ️  Already enrolled in section: ${section.name}`);
                        }
                    } else {
                        console.log(`   ⚠️  Section not found: ${studentData.section}`);
                    }
                } else {
                    console.log(`ℹ️  Student already exists: ${existingStudent.fullName}`);
                }
            } catch (error) {
                console.error(`❌ Error creating student ${studentData.studentID}:`, error.message);
            }
        }

        console.log('\n📊 Student Seeding Summary:');
        console.log(`✅ Created ${createdCount} new students`);
        console.log(`✅ Enrolled ${enrolledCount} students in sections`);
        console.log('🎉 Student data generation completed!');
        
    } catch (error) {
        console.error('❌ Error generating student data:', error);
    } finally {
        mongoose.connection.close();
    }
};

// Run the seed
connectDB().then(() => {
    generateStudentData().then(() => {
        console.log('🏁 Seeding process finished');
        process.exit(0);
    });
});