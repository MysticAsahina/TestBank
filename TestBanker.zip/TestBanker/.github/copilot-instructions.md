Repository: TestBank (p3finals)

Overview
- This is an Express + EJS server for a "Test Bank System" (backend + simple server-rendered views).
- Main entry: `server.js` (express app, session setup, MongoDB via `mongoose`, mounts routes from `routes/` and file upload router at `utils/fileUpload.js`).

Big-picture architecture
- Single Node/Express monolith serving EJS views from `views/` and static files from `public/`.
- Role-based routing: `routes/index.js` mounts `/dean`, `/professor`, `/student` and `/auth` sub-routers. See `routes/` for per-role logic.
- Data models: Mongoose models live in `models/` (e.g., `Test.js`, `Admin.js`, `Student.js`, `Section.js`). Tests and test structure are modeled inside `models/Test.js` with nested question schemas.
- File uploads: `utils/fileUpload.js` exposes multiple endpoints (/upload, /uploads, /upload/question, /upload/correct, /upload/incorrect) which save files into `public/TestImages`, `public/QuestionFile`, `public/CorrectFile`, `public/IncorrectFile` respectively. Routes expect returned URLs like `/QuestionFile/<filename>`.

Key developer workflows
- Start server locally: use `npm run dev` (nodemon) or `npm start`. Main script is `server.js`.
- Environment: uses `dotenv`; expected env vars: `MONGO_URI`, `PORT`, `SESSION_SECRET`, `EMAIL_USER`, `EMAIL_PASS`. `server.js` logs presence of these at startup.
- Static files and uploads: `public/` is served statically. Uploaded files are stored under `public/*` directories created by `utils/fileUpload.js`.

Project-specific conventions & patterns
- Views are EJS templates under `views/` with role subfolders (e.g., `views/dean/`). Render calls often pass `title` and `user` from `res.locals.user` (session middleware in `server.js`).
- Session-based auth: session middleware stores `req.session.user`; route handlers check `req.session.user.role` to redirect to proper dashboards (see `routes/index.js`).
- Mongoose usage: models export default the Mongoose model and often include virtuals (e.g., `Test.totalQuestions`) and pre-save hooks (e.g., `Admin` updates `updatedAt`). Prefer using model methods or static queries rather than raw collection operations.
- File URL patterns: any uploaded file URL is returned as `/TestImages/<file>` or `/QuestionFile/<file>` etc. Frontend templates expect these relative paths to be served from `/TestImages` or static `public/`.

Integration points & external dependencies
- MongoDB via `mongoose` (connect string in `MONGO_URI`). Tests, admins, students stored in MongoDB.
- Email: `nodemailer` is used in some routes (see `routes/adminRoutes.js`) — credentials currently hard-coded placeholder; prefer using `EMAIL_USER`/`EMAIL_PASS` env vars and updating transporter config.
- File storage: local filesystem under `public/`. No cloud storage integration.

Common patterns and quick examples
- Redirect to dashboard by role (from `routes/index.js`):
  - if user.role === 'Student' -> `/student/dashboard`
  - if user.role === 'Professor' -> `/professor/dashboard`
  - if user.role === 'Dean' -> `/dean/dashboard`
- Upload a question asset: POST `/upload/question` form field name `file` -> returns `{ url: '/QuestionFile/<filename>' }` (see `utils/fileUpload.js`).
- Test model shape (examples from `models/Test.js`):
  - test.questions is an array of { text, type, points, choices?, correctAnswer?, files?: ["/QuestionFile/..."] }
  - use Test.totalPoints virtual to compute sum of points.

When making changes
- Avoid changing `server.js` startup order for dotenv, session, and static middleware. Environment is loaded first, then express app creation, static middleware, session, and routes.
- Keep upload directories and filename scheme (timestamp + random suffix) unchanged unless you update all routes and templates that consume the returned URLs.
- If modifying models, update any routes that call them (search within `routes/`) — codebase uses direct Mongoose queries in routes, so changes may ripple across several files.

Edge cases & gotchas discovered
- Some email logic in `routes/adminRoutes.js` uses hard-coded credentials and may not use env vars; update to env vars before enabling in production.
- `server.js` prints presence of sensitive env vars — do not commit real values to git.
- Many routes render EJS views that expect `res.locals.user` to exist; ensure session middleware remains configured and named `user`.

Files to inspect when working on features
- `server.js` — app boot, middleware order, env checks
- `routes/` — role-based routes and auth
- `utils/fileUpload.js` — upload endpoints and storage paths
- `models/` — data shapes (especially `Test.js` and `Admin.js`)
- `views/` — templates that use file URL patterns and `user` in locals

Minimal acceptance criteria for PRs
- Server still starts with `npm run dev` and connects to MongoDB (use a local test URI if needed).
- Upload endpoints return valid URLs and files appear under `public/`.
- No leaking of real secrets into commits (use `.env` and .gitignore).

If you need more
- Ask the maintainer for sample `.env` values for `MONGO_URI`, `EMAIL_USER`, `EMAIL_PASS`, and a test admin account. Also ask if nodemailer should be configured to use environment credentials.
