import express from 'express';
import mongoose from 'mongoose';
import session from 'express-session';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

// Load environment variables early
dotenv.config();

/**
 * Route imports
 */
import routes from './routes/index.js';
import setupPasswordRoutes from './routes/passwordReset.js';
import adminRoutes from './routes/adminRoutes.js';
import fileUploadRouter from './utils/fileUpload.js';
import deanRoutes from './routes/deanPages/index.js';
import testsApi from './routes/api/tests.js';

/**
 * Small environment sanity check printed at startup
 */
console.log('🔧 Environment check:');
console.log('EMAIL_USER exists:', !!process.env.EMAIL_USER);
console.log('EMAIL_PASS exists:', !!process.env.EMAIL_PASS);
console.log('PORT:', process.env.PORT);
console.log('SESSION_SECRET exists:', !!process.env.SESSION_SECRET);

// __dirname setup
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Express app setup
const app = express();

// Middleware to parse JSON and URL-encoded bodies
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve public static assets
app.use(express.static(path.join(__dirname, 'public')));

// Backwards-compatible static mount for uploaded test images
app.use('/TestImages', express.static(path.join(__dirname, 'public', 'TestImages')));

// File upload endpoints (keeps original behavior)
// NOTE: fileUploadRouter exposes routes like POST /upload and /uploads (see utils/fileUpload.js)
app.use('/', fileUploadRouter);

// Set EJS as the templating engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Session configuration
const sessionConfig = {
  secret: process.env.SESSION_SECRET || 'p3finals-secret-key-2024',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false, // set to true if using HTTPS
    maxAge: 24 * 60 * 60 * 1000, // 1 day
    httpOnly: true,
  },
};

app.use(session(sessionConfig));

// Middleware to expose session user to views
app.use((req, res, next) => {
  console.log('🔄 Session middleware - User:', req.session?.user);
  res.locals.user = req.session?.user || null;
  next();
});

// Mount routes
app.use('/', routes);
app.use('/', setupPasswordRoutes);
app.use('/', adminRoutes);
app.use('/dean', deanRoutes);
app.use('/api', testsApi);

// Start server and connect to MongoDB
const PORT = process.env.PORT || 8000;

async function startServer() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ Connected to MongoDB');

    app.listen(PORT, () => {
      console.log(`🚀 Server running on http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('❌ MongoDB connection error:', err);
    process.exit(1);
  }
}

// Global error handlers
process.on('unhandledRejection', (reason) => {
  console.error('❌ Unhandled Rejection:', reason);
});
process.on('uncaughtException', (err) => {
  console.error('❌ Uncaught Exception:', err);
  process.exit(1);
});

// Invoke server start
startServer();