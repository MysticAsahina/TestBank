const mongoose = require('mongoose');
const User = require('../models/User');
require('dotenv').config();

async function setupAdmin() {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGO_URI);
    console.log('Connected to MongoDB for admin setup');

    // Check if any admin exists
    const existingAdmin = await User.findOne({ role: 'admin' });
    
    if (existingAdmin) {
      console.log('✅ Admin account already exists:');
      console.log(`   Email: ${existingAdmin.email}`);
      console.log(`   Name: ${existingAdmin.name}`);
      console.log('   Role: Admin');
      console.log('\n🌐 You can login at: http://localhost:5000');
      return;
    }

    // Create default admin account
    const adminUser = new User({
      name: 'System Administrator',
      email: 'admin@quizbank.com',
      password: 'admin123',
      role: 'admin'
    });

    await adminUser.save();
    
    console.log('🎉 Default admin account created successfully!');
    console.log('📧 Email: admin@quizbank.com');
    console.log('🔑 Password: admin123');
    console.log('👤 Role: Admin');
    console.log('\n⚠️  IMPORTANT: Please change the default password after first login!');
    console.log('\n🌐 You can now login at: http://localhost:5000');

  } catch (error) {
    console.error('❌ Error setting up admin account:', error.message);
  } finally {
    await mongoose.disconnect();
    console.log('Disconnected from MongoDB');
  }
}

// Run the setup
setupAdmin();

