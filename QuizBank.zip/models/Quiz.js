const mongoose = require("mongoose");

const quizSchema = new mongoose.Schema({
  title: { type: String, required: true },
  subjectCode: { type: String, required: true },
  description: { type: String },
  access: { type: String, enum: ['public', 'private'], default: 'public' },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  isActive: { type: Boolean, default: true },
  shuffleQuestions: { type: Boolean, default: true },
  timeLimit: { type: Number, default: 0 }, // in minutes, 0 means no limit
  totalPoints: { type: Number, default: 0 }
}, { timestamps: true });

module.exports = mongoose.model("Quiz", quizSchema);
