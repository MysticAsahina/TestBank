const mongoose = require("mongoose");

const questionSchema = new mongoose.Schema({
  quizId: { type: mongoose.Schema.Types.ObjectId, ref: 'Quiz', required: true },
  questionText: { type: String, required: true },
  questionType: { 
    type: String, 
    enum: ['multiple_choice', 'true_false', 'short_answer'], 
    required: true 
  },
  options: [{
    text: String,
    isCorrect: { type: Boolean, default: false }
  }],
  correctAnswer: { type: String, required: true },
  points: { type: Number, default: 1 },
  order: { type: Number, default: 0 }
}, { timestamps: true });

module.exports = mongoose.model("Question", questionSchema);
