- Admin Account
Email: admin@quizbank.com
Password: admin123

This project includes contributions from **Astin (Justine Tabunan)**.  
Removing or altering this credit is not allowed.