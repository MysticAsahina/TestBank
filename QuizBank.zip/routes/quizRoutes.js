const express = require("express");
const Quiz = require("../models/Quiz");
const Question = require("../models/Question");
const QuizAttempt = require("../models/QuizAttempt");
const { auth, adminAuth } = require("../middleware/auth");
const router = express.Router();

// Get all quizzes (public and user's own)
router.get("/", auth, async (req, res) => {
  try {
    const filter = req.user.role === 'admin' 
      ? {} 
      : { $or: [{ access: 'public' }, { createdBy: req.user._id }] };
    
    const quizzes = await Quiz.find(filter)
      .populate('createdBy', 'name email')
      .sort({ createdAt: -1 });
    
    res.json(quizzes);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get single quiz with questions
router.get("/:id", auth, async (req, res) => {
  try {
    const quiz = await Quiz.findById(req.params.id).populate('createdBy', 'name email');
    if (!quiz) {
      return res.status(404).json({ error: "Quiz not found" });
    }

    // Check access
    if (quiz.access === 'private' && quiz.createdBy._id.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ error: "Access denied" });
    }

    const questions = await Question.find({ quizId: req.params.id }).sort({ order: 1 });
    res.json({ quiz, questions });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Create quiz (admin only)
router.post("/", adminAuth, async (req, res) => {
  try {
    const { title, subjectCode, description, access, shuffleQuestions, timeLimit } = req.body;
    
    const quiz = new Quiz({
      title,
      subjectCode,
      description,
      access: access || 'public',
      createdBy: req.user._id,
      shuffleQuestions: shuffleQuestions !== false,
      timeLimit: timeLimit || 0
    });

    await quiz.save();
    res.status(201).json(quiz);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Update quiz (admin only)
router.put("/:id", adminAuth, async (req, res) => {
  try {
    const quiz = await Quiz.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    
    if (!quiz) {
      return res.status(404).json({ error: "Quiz not found" });
    }

    res.json(quiz);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Delete quiz (admin only)
router.delete("/:id", adminAuth, async (req, res) => {
  try {
    const quiz = await Quiz.findByIdAndDelete(req.params.id);
    if (!quiz) {
      return res.status(404).json({ error: "Quiz not found" });
    }

    // Delete associated questions
    await Question.deleteMany({ quizId: req.params.id });
    await QuizAttempt.deleteMany({ quizId: req.params.id });

    res.json({ message: "Quiz deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add question to quiz (admin only)
router.post("/:id/questions", adminAuth, async (req, res) => {
  try {
    const { questionText, questionType, options, correctAnswer, points } = req.body;
    
    const question = new Question({
      quizId: req.params.id,
      questionText,
      questionType,
      options: options || [],
      correctAnswer,
      points: points || 1
    });

    await question.save();
    
    // Update quiz total points by recalculating from all questions
    const allQuestions = await Question.find({ quizId: req.params.id });
    const totalPoints = allQuestions.reduce((sum, q) => sum + q.points, 0);
    
    const quiz = await Quiz.findById(req.params.id);
    quiz.totalPoints = totalPoints;
    await quiz.save();

    res.status(201).json(question);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Update question (admin only)
router.put("/:id/questions/:questionId", adminAuth, async (req, res) => {
  try {
    const question = await Question.findByIdAndUpdate(
      req.params.questionId,
      req.body,
      { new: true }
    );
    
    if (!question) {
      return res.status(404).json({ error: "Question not found" });
    }

    res.json(question);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Delete question (admin only)
router.delete("/:id/questions/:questionId", adminAuth, async (req, res) => {
  try {
    const question = await Question.findByIdAndDelete(req.params.questionId);
    if (!question) {
      return res.status(404).json({ error: "Question not found" });
    }

    // Update quiz total points by recalculating from all remaining questions
    const allQuestions = await Question.find({ quizId: req.params.id });
    const totalPoints = allQuestions.reduce((sum, q) => sum + q.points, 0);
    
    const quiz = await Quiz.findById(req.params.id);
    quiz.totalPoints = totalPoints;
    await quiz.save();

    res.json({ message: "Question deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Start quiz attempt (student)
router.post("/:id/start", auth, async (req, res) => {
  try {
    const quiz = await Quiz.findById(req.params.id);
    if (!quiz) {
      return res.status(404).json({ error: "Quiz not found" });
    }

    // Check if user already attempted this quiz
    const existingAttempt = await QuizAttempt.findOne({
      quizId: req.params.id,
      studentId: req.user._id
    });

    if (existingAttempt) {
      return res.status(400).json({ error: "You have already attempted this quiz" });
    }

    // Get questions and shuffle if enabled
    let questions = await Question.find({ quizId: req.params.id });
    if (quiz.shuffleQuestions) {
      questions = questions.sort(() => Math.random() - 0.5);
    }

    // Create quiz attempt
    const attempt = new QuizAttempt({
      quizId: req.params.id,
      studentId: req.user._id,
      maxScore: quiz.totalPoints
    });

    await attempt.save();

    // Add quiz data to the response
    const attemptWithQuiz = {
      ...attempt.toObject(),
      quizId: quiz
    };

    res.json({ attempt: attemptWithQuiz, questions });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Retake quiz (student) - allows retaking even if already attempted
router.post("/:id/retake", auth, async (req, res) => {
  try {
    const quiz = await Quiz.findById(req.params.id);
    if (!quiz) {
      return res.status(404).json({ error: "Quiz not found" });
    }

    // Delete existing attempt if any
    await QuizAttempt.deleteOne({
      quizId: req.params.id,
      studentId: req.user._id
    });

    // Get questions and shuffle if enabled
    let questions = await Question.find({ quizId: req.params.id });
    if (quiz.shuffleQuestions) {
      questions = questions.sort(() => Math.random() - 0.5);
    }

    // Create new quiz attempt
    const attempt = new QuizAttempt({
      quizId: req.params.id,
      studentId: req.user._id,
      maxScore: quiz.totalPoints
    });

    await attempt.save();

    // Add quiz data to the response
    const attemptWithQuiz = {
      ...attempt.toObject(),
      quizId: quiz
    };

    res.json({ attempt: attemptWithQuiz, questions });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Submit quiz answers (student)
router.post("/:id/submit", auth, async (req, res) => {
  try {
    const { answers } = req.body;
    
    const attempt = await QuizAttempt.findOne({
      quizId: req.params.id,
      studentId: req.user._id
    });

    if (!attempt) {
      return res.status(404).json({ error: "Quiz attempt not found" });
    }

    if (attempt.isCompleted) {
      return res.status(400).json({ error: "Quiz already submitted" });
    }

    // Calculate score
    let totalScore = 0;
    const questionAnswers = [];

    for (const answer of answers) {
      const question = await Question.findById(answer.questionId);
      if (question) {
        const isCorrect = question.correctAnswer.toLowerCase() === answer.answer.toLowerCase();
        const points = isCorrect ? question.points : 0;
        totalScore += points;

        questionAnswers.push({
          questionId: answer.questionId,
          answer: answer.answer,
          isCorrect,
          points
        });
      }
    }

    // Update attempt
    attempt.answers = questionAnswers;
    attempt.totalScore = totalScore;
    attempt.percentage = (totalScore / attempt.maxScore) * 100;
    attempt.isCompleted = true;
    attempt.completedAt = new Date();

    await attempt.save();

    res.json({
      message: "Quiz submitted successfully",
      score: totalScore,
      maxScore: attempt.maxScore,
      percentage: attempt.percentage
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Check if student has attempted a quiz
router.get("/:id/attempt-status", auth, async (req, res) => {
  try {
    const attempt = await QuizAttempt.findOne({
      quizId: req.params.id,
      studentId: req.user._id
    });

    if (attempt) {
      // Always populate quiz data manually to ensure it's available
      const quiz = await Quiz.findById(req.params.id);
      const attemptWithQuiz = {
        ...attempt.toObject(),
        quizId: quiz
      };
      
      res.json({ 
        hasAttempted: true,
        attempt: attemptWithQuiz
      });
    } else {
      res.json({ 
        hasAttempted: false,
        attempt: null
      });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get quiz results (admin or quiz creator)
router.get("/:id/results", auth, async (req, res) => {
  try {
    const quiz = await Quiz.findById(req.params.id);
    if (!quiz) {
      return res.status(404).json({ error: "Quiz not found" });
    }

    // Check if user can view results
    if (quiz.createdBy.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ error: "Access denied" });
    }

    const attempts = await QuizAttempt.find({ quizId: req.params.id })
      .populate('studentId', 'name email')
      .populate('quizId', 'title subjectCode')
      .sort({ completedAt: -1 });

    res.json(attempts);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get detailed quiz results with questions (admin or quiz creator)
router.get("/:id/results/detailed", auth, async (req, res) => {
  try {
    const quiz = await Quiz.findById(req.params.id);
    if (!quiz) {
      return res.status(404).json({ error: "Quiz not found" });
    }

    // Check if user can view results
    if (quiz.createdBy.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ error: "Access denied" });
    }

    const attempts = await QuizAttempt.find({ quizId: req.params.id })
      .populate('studentId', 'name email')
      .populate('quizId', 'title subjectCode')
      .sort({ completedAt: -1 });

    const questions = await Question.find({ quizId: req.params.id });

    // Recalculate total points to ensure accuracy
    const calculatedTotalPoints = questions.reduce((sum, q) => sum + q.points, 0);
    if (quiz.totalPoints !== calculatedTotalPoints) {
      quiz.totalPoints = calculatedTotalPoints;
      await quiz.save();
    }

    res.json({ quiz, attempts, questions });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
