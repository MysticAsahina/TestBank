# Quiz Management System

A comprehensive quiz management system built with Node.js, Express, MongoDB, and modern web technologies. This system allows administrators to create and manage quizzes while students can take quizzes with question shuffling capabilities.

## Features

### Admin Features
- **User Authentication**: Secure login/register system with role-based access
- **Quiz Management**: Create, edit, delete quizzes with detailed configuration
- **Question Management**: Add multiple choice, true/false, and short answer questions
- **Results Tracking**: View and analyze student performance
- **User Management**: Monitor all registered users

### Student Features
- **Quiz Taking**: Take quizzes with a clean, intuitive interface
- **Question Shuffling**: Questions are randomized for each attempt (if enabled by admin)
- **Time Management**: Optional time limits for quizzes
- **Results View**: View detailed results after quiz completion
- **Progress Tracking**: Visual progress indicators during quiz taking

### Technical Features
- **Responsive Design**: Works on desktop and mobile devices
- **Real-time Updates**: Live timer and progress tracking
- **Secure Authentication**: JWT-based authentication with session management
- **Database Integration**: MongoDB for data persistence
- **Modern UI**: Built with Tailwind CSS for a clean, professional look

## Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd QuizBank
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp env.example .env
   ```
   
   Edit the `.env` file with your configuration:
   ```env
   MONGO_URI=mongodb://localhost:27017/quizbank
   JWT_SECRET=your-super-secret-jwt-key-here
   SESSION_SECRET=your-super-secret-session-key-here
   PORT=5000
   NODE_ENV=development
   ```

4. **Start MongoDB**
   Make sure MongoDB is running on your system. You can use:
   - Local MongoDB installation
   - MongoDB Atlas (cloud)
   - Docker: `docker run -d -p 27017:27017 mongo`

5. **Run the application**
   ```bash
   # Development mode
   npm run dev
   
   # Production mode
   npm start
   ```

6. **Access the application**
   Open your browser and go to `http://localhost:5000`

## Usage

### First Time Setup

1. **Automatic Admin Account Creation**
   - The system automatically creates a default admin account on first startup
   - **Email**: `admin@quizbank.com`
   - **Password**: `admin123`
   - **⚠️ Important**: Change the default password after first login!

2. **Alternative: Manual Admin Setup**
   - If you prefer to create your own admin account, you can:
   - Go to the registration page
   - Select "Admin" as the account type
   - Complete the registration form

3. **Create Your First Quiz**
   - Login with your admin account
   - Navigate to "Quiz Management"
   - Click "Create New Quiz"
   - Fill in quiz details and add questions

### For Students

1. **Register a Student Account**
   - Go to the registration page
   - Select "Student" as the account type
   - Complete the registration form

2. **Take Quizzes**
   - Login with your student account
   - Browse available quizzes
   - Click "Start Quiz" to begin
   - Answer questions and submit when complete

### For Administrators

1. **Create Quizzes**
   - Use the admin panel to create new quizzes
   - Configure quiz settings (time limits, question shuffling, access level)
   - Add questions with different types (multiple choice, true/false, short answer)

2. **Monitor Results**
   - View quiz results and student performance
   - Track completion rates and scores
   - Manage user accounts

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register a new user
- `POST /api/auth/login` - Login user
- `POST /api/auth/logout` - Logout user
- `GET /api/auth/me` - Get current user info

### Quizzes
- `GET /api/quizzes` - Get all quizzes (filtered by user role)
- `GET /api/quizzes/:id` - Get specific quiz with questions
- `POST /api/quizzes` - Create new quiz (admin only)
- `PUT /api/quizzes/:id` - Update quiz (admin only)
- `DELETE /api/quizzes/:id` - Delete quiz (admin only)

### Questions
- `POST /api/quizzes/:id/questions` - Add question to quiz (admin only)
- `PUT /api/quizzes/:id/questions/:questionId` - Update question (admin only)
- `DELETE /api/quizzes/:id/questions/:questionId` - Delete question (admin only)

### Quiz Attempts
- `POST /api/quizzes/:id/start` - Start quiz attempt
- `POST /api/quizzes/:id/submit` - Submit quiz answers
- `GET /api/quizzes/:id/results` - Get quiz results (admin/creator only)

### Users
- `GET /api/users` - Get all users (admin only)
- `GET /api/users/:id` - Get specific user
- `PUT /api/users/:id` - Update user
- `DELETE /api/users/:id` - Delete user

## Database Schema

### User Model
```javascript
{
  name: String,
  email: String (unique),
  password: String (hashed),
  role: String (enum: ['admin', 'student']),
  isActive: Boolean,
  createdAt: Date,
  updatedAt: Date
}
```

### Quiz Model
```javascript
{
  title: String,
  subjectCode: String,
  description: String,
  access: String (enum: ['public', 'private']),
  createdBy: ObjectId (ref: User),
  isActive: Boolean,
  shuffleQuestions: Boolean,
  timeLimit: Number (minutes),
  totalPoints: Number,
  createdAt: Date,
  updatedAt: Date
}
```

### Question Model
```javascript
{
  quizId: ObjectId (ref: Quiz),
  questionText: String,
  questionType: String (enum: ['multiple_choice', 'true_false', 'short_answer']),
  options: [{
    text: String,
    isCorrect: Boolean
  }],
  correctAnswer: String,
  points: Number,
  order: Number,
  createdAt: Date,
  updatedAt: Date
}
```

### QuizAttempt Model
```javascript
{
  quizId: ObjectId (ref: Quiz),
  studentId: ObjectId (ref: User),
  answers: [{
    questionId: ObjectId (ref: Question),
    answer: String,
    isCorrect: Boolean,
    points: Number
  }],
  totalScore: Number,
  maxScore: Number,
  percentage: Number,
  timeSpent: Number (seconds),
  completedAt: Date,
  isCompleted: Boolean,
  createdAt: Date,
  updatedAt: Date
}
```

## Security Features

- **Password Hashing**: Uses bcryptjs for secure password storage
- **JWT Authentication**: Secure token-based authentication
- **Session Management**: Express sessions for additional security
- **Role-based Access**: Different permissions for admin and student users
- **Input Validation**: Server-side validation for all inputs
- **CORS Protection**: Configured for secure cross-origin requests

## Development

### Project Structure
```
QuizBank/
├── models/           # MongoDB models
├── routes/           # API routes
├── middleware/       # Custom middleware
├── public/           # Static files (HTML, CSS, JS)
├── index.js          # Main server file
├── package.json      # Dependencies and scripts
└── README.md         # This file
```

### Available Scripts
- `npm start` - Start the production server
- `npm run dev` - Start the development server with nodemon
- `npm install` - Install dependencies

### Technologies Used
- **Backend**: Node.js, Express.js
- **Database**: MongoDB with Mongoose ODM
- **Authentication**: JWT, bcryptjs, express-session
- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Styling**: Tailwind CSS
- **HTTP Client**: Axios

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the ISC License.

## Transferring the Project

When transferring this project to another person or organization:

1. **Automatic Admin Setup**: The system will automatically create a default admin account on first startup
2. **Default Credentials**: 
   - Email: `admin@quizbank.com`
   - Password: `admin123`
3. **Security**: The new owner should immediately change the default password
4. **Database**: The system will work with any MongoDB instance (local or cloud)

### Quick Transfer Steps:
1. Copy the entire project folder
2. Run `npm install` to install dependencies
3. Set up your `.env` file with MongoDB connection
4. Run `npm start` - admin account will be created automatically
5. Login and change the default password

## Support

For support and questions, please create an issue in the repository or contact the development team.
