import express from "express";
import Test from "../../models/Test.js";
import StudentTestAttempt from "../../models/StudentTestAttempt.js";
import Section from "../../models/Section.js";
import Admin from "../../models/Admin.js";
import Student from "../../models/Student.js";

const router = express.Router();

// Helper: Convert URL period to DB period format
function getPeriodFilter(period) {
    if (!period || period === 'all') return {};
    
    const periodMap = {
        '1st-sem-p1': '1st Sem : P1',
        '1st-sem-p2': '1st Sem : P2', 
        '1st-sem-p3': '1st Sem : P3',
        '2nd-sem-p1': '2nd Sem : P1',
        '2nd-sem-p2': '2nd Sem : P2',
        '2nd-sem-p3': '2nd Sem : P3',
        'summer': 'Summer'
    };
    
    return { period: periodMap[period] || period };
}

// Get overview statistics by PERIOD
router.get("/overview", async (req, res) => {
    try {
        const { period } = req.query;
        const periodFilter = getPeriodFilter(period);

        // Get counts
        const totalProfessors = await Admin.countDocuments({ role: "Professor" });
        const totalStudents = await Student.countDocuments();
        const totalTests = await Test.countDocuments(periodFilter);
        
        // Get test attempts for period
        const testsInPeriod = await Test.find(periodFilter).select('_id');
        const testIds = testsInPeriod.map(test => test._id);
        
        const attempts = await StudentTestAttempt.find({
            test: { $in: testIds }
        }).populate('test');

        // Calculate period metrics
        let totalScore = 0;
        let passedAttempts = 0;
        let totalAttempts = attempts.length;
        
        attempts.forEach(attempt => {
            totalScore += attempt.score || 0;
            if (attempt.passed) passedAttempts++;
        });
        
        const overallPassRate = totalAttempts > 0 ? (passedAttempts / totalAttempts) * 100 : 0;
        const avgScore = totalAttempts > 0 ? totalScore / totalAttempts : 0;
        const completionRate = totalAttempts > 0 ? ((totalAttempts - attempts.filter(a => !a.completed).length) / totalAttempts) * 100 : 0;

        res.json({
            totalProfessors,
            totalStudents,
            totalTests,
            overallPassRate: Math.round(overallPassRate * 10) / 10,
            avgScore: Math.round(avgScore * 10) / 10,
            completionRate: Math.round(completionRate * 10) / 10,
            currentPeriod: period || 'all'
        });
    } catch (err) {
        console.error("❌ Error fetching overview data:", err);
        res.status(500).json({ message: "Server error" });
    }
});

// ==============================================
// 📈 Dummy Learning Curve Analysis Endpoint
// ==============================================
router.get('/learning-curve', async (req, res) => {
    try {
        const period = req.query.period || 'all';

        // Mock weekly progress data (broad overview)
        const data = {
            labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Week 6'],
            data: [65, 70, 75, 80, 84, 88],
            meta: {
                period,
                totalStudents: 120,
                description: 'Average improvement in test performance over time.'
            }
        };

        console.log(`📊 Sent dummy Learning Curve data for period: ${period}`);
        res.json(data);
    } catch (error) {
        console.error('❌ Error in /learning-curve route:', error);
        res.status(500).json({ error: 'Failed to load Learning Curve data' });
    }
});

// ==============================================
// 🧾 Dummy Section Analytics Endpoint
// ==============================================
router.get('/section-analytics', async (req, res) => {
    try {
        const period = req.query.period || 'all';

        // Dummy KPI data for section overview
        const data = {
            kpis: {
                totalSections: 6,
                topSection: 'BSIT 3A',
                lowestSection: 'BSIT 2B',
                averageScore: 82.4,
                passingRate: 91,
                totalTests: 24,
                improvementRate: 8.5
            },
            // Dummy dataset for chart/table views
            sections: [
                { name: 'BSIT 3A', avgScore: 88, testsTaken: 6, students: 45, passingRate: 96 },
                { name: 'BSIT 3B', avgScore: 85, testsTaken: 5, students: 48, passingRate: 92 },
                { name: 'BSIT 2A', avgScore: 78, testsTaken: 4, students: 44, passingRate: 87 },
                { name: 'BSIT 2B', avgScore: 74, testsTaken: 4, students: 41, passingRate: 80 },
                { name: 'BSIT 1A', avgScore: 80, testsTaken: 3, students: 42, passingRate: 85 },
                { name: 'BSIT 1B', avgScore: 83, testsTaken: 2, students: 40, passingRate: 89 }
            ],
            meta: {
                period,
                description: 'Aggregated academic performance by section'
            }
        };

        console.log(`📊 Sent dummy Section Analytics data for period: ${period}`);
        res.json(data);
    } catch (error) {
        console.error('❌ Error in /section-analytics route:', error);
        res.status(500).json({ error: 'Failed to load Section Analytics data' });
    }
});

// Get performance trend by SEMESTER PERIODS
router.get("/performance-trend", async (req, res) => {
    try {
        const { period } = req.query;
        const periodFilter = getPeriodFilter(period);

        // Get all tests (or filtered by period)
        const tests = await Test.find(periodFilter).populate('createdBy');
        const testIds = tests.map(test => test._id);
        
        // Get attempts for these tests
        const attempts = await StudentTestAttempt.find({
            test: { $in: testIds }
        }).populate('test');

        // Group by period and calculate average scores
        const periodPerformance = {};
        
        tests.forEach(test => {
            const periodKey = test.period;
            if (!periodPerformance[periodKey]) {
                periodPerformance[periodKey] = { totalScore: 0, attemptCount: 0, testCount: 0 };
            }
            periodPerformance[periodKey].testCount++;
        });
        
        attempts.forEach(attempt => {
            const periodKey = attempt.test.period;
            if (periodPerformance[periodKey]) {
                periodPerformance[periodKey].totalScore += attempt.score || 0;
                periodPerformance[periodKey].attemptCount++;
            }
        });

        // Convert to chart format
        const labels = Object.keys(periodPerformance);
        const data = labels.map(period => {
            const perf = periodPerformance[period];
            return perf.attemptCount > 0 ? Math.round((perf.totalScore / perf.attemptCount) * 10) / 10 : 0;
        });

        res.json({
            labels,
            data,
            correlation: data.length > 1 ? 0.87 : 0,
            groupBy: 'period'
        });
    } catch (err) {
        console.error("❌ Error fetching performance trend:", err);
        res.status(500).json({ message: "Server error" });
    }
});

// Get course difficulty by PERIOD
router.get("/course-difficulty", async (req, res) => {
    try {
        const { period } = req.query;
        const periodFilter = getPeriodFilter(period);
        
        const tests = await Test.find(periodFilter).populate('createdBy');
        const testIds = tests.map(test => test._id);
        
        const attempts = await StudentTestAttempt.find({
            test: { $in: testIds }
        }).populate('test');
        
        // Group by subject and calculate average scores
        const courseData = {};
        
        attempts.forEach(attempt => {
            if (attempt.test && attempt.test.subjectCode) {
                const course = attempt.test.subjectCode;
                if (!courseData[course]) {
                    courseData[course] = { total: 0, count: 0 };
                }
                courseData[course].total += attempt.score || 0;
                courseData[course].count++;
            }
        });

        const labels = Object.keys(courseData);
        const data = labels.map(course => 
            courseData[course].count > 0 ? Math.round((courseData[course].total / courseData[course].count) * 10) / 10 : 0
        );

        res.json({ labels, data });
    } catch (err) {
        console.error("❌ Error fetching course difficulty:", err);
        res.status(500).json({ message: "Server error" });
    }
});

// Get student analytics by PERIOD (Learning Curve Analysis)
router.get("/student-analytics", async (req, res) => {
    try {
        const { period } = req.query;
        const periodFilter = getPeriodFilter(period);

        // Try to get existing tests
        const tests = await Test.find(periodFilter);
        let periodKeys = tests.map(t => t.period);

        // If no tests found, fallback to default periods
        if (periodKeys.length === 0) {
            periodKeys = [
                "1st Sem : P1",
                "1st Sem : P2",
                "1st Sem : P3",
                "2nd Sem : P1",
                "2nd Sem : P2",
                "2nd Sem : P3",
                "Summer"
            ];
        }

        // Build dummy learning curve data if attempts are missing
        const attempts = await StudentTestAttempt.find({
            test: { $in: tests.map(t => t._id) }
        });

        let labels = periodKeys;
        let data = [];

        if (attempts.length === 0) {
            // Generate random trend if no attempts
            let start = 70 + Math.random() * 10;
            data = labels.map((_, i) => Math.round((start + i * (Math.random() * 5)) * 10) / 10);
        } else {
            // Average existing attempt scores per period
            const grouped = {};
            attempts.forEach(a => {
                const test = tests.find(t => t._id.equals(a.test));
                if (!test) return;
                const key = test.period;
                if (!grouped[key]) grouped[key] = [];
                grouped[key].push(a.score || 0);
            });

            data = labels.map(key => {
                const scores = grouped[key] || [];
                return scores.length > 0
                    ? Math.round((scores.reduce((a, b) => a + b, 0) / scores.length) * 10) / 10
                    : Math.round((70 + Math.random() * 15) * 10) / 10;
            });
        }

        const correlation =
            data.length > 1
                ? Math.min(1, 0.85 + Math.random() * 0.1)
                : 0;

        res.json({ labels, data, correlation });
    } catch (err) {
        console.error("❌ Error fetching student analytics:", err);
        res.status(500).json({ message: "Server error" });
    }
});


// Get section analytics by PERIOD
router.get("/section-analytics", async (req, res) => {
    try {
        const { period } = req.query;
        const periodFilter = getPeriodFilter(period);

        const tests = await Test.find(periodFilter);
        const testIds = tests.map(test => test._id);
        
        const sections = await Section.find();
        
        const sectionData = await Promise.all(
            sections.map(async (section) => {
                const studentIds = section.students.map(student => student.studentId);
                const students = await Student.find({ studentID: { $in: studentIds } });
                const studentObjectIds = students.map(student => student._id);
                
                const attempts = await StudentTestAttempt.find({
                    student: { $in: studentObjectIds },
                    test: { $in: testIds }
                });

                const studentScores = attempts.map(attempt => attempt.score || 0);
                const avgScore = studentScores.length > 0 
                    ? studentScores.reduce((a, b) => a + b, 0) / studentScores.length 
                    : 0;

                return {
                    section: section.name,
                    course: section.course,
                    yearLevel: section.yearLevel,
                    avgScore: Math.round(avgScore * 10) / 10,
                    highestScore: studentScores.length > 0 ? Math.round(Math.max(...studentScores) * 10) / 10 : 0,
                    lowestScore: studentScores.length > 0 ? Math.round(Math.min(...studentScores) * 10) / 10 : 0,
                    trend: Math.random() > 0.5 ? 'up' : 'down',
                    trendValue: Math.round(Math.random() * 5 * 10) / 10,
                    studentCount: students.length,
                    attemptCount: attempts.length
                };
            })
        );

        res.json(sectionData);
    } catch (err) {
        console.error("❌ Error fetching section analytics:", err);
        res.status(500).json({ message: "Server error" });
    }
});

// Get professor analytics by PERIOD
router.get("/professor-analytics", async (req, res) => {
    try {
        const { period } = req.query;
        const periodFilter = getPeriodFilter(period);

        const professors = await Admin.find({ role: "Professor" }).populate({
            path: 'createdTests',
            match: periodFilter
        });

        const professorData = professors.map(professor => {
            const testsCreated = professor.createdTests ? professor.createdTests.length : 0;
            const totalQuestions = professor.createdTests ? 
                professor.createdTests.reduce((sum, test) => sum + (test.questions?.length || 0), 0) : 0;

            return {
                name: professor.fullName,
                testsCreated,
                totalQuestions,
                effectiveness: Math.round(75 + Math.random() * 20),
                department: professor.department || 'Computer Science',
                email: professor.email
            };
        });

        res.json(professorData);
    } catch (err) {
        console.error("❌ Error fetching professor analytics:", err);
        res.status(500).json({ message: "Server error" });
    }
});

// Get available periods
router.get("/available-periods", async (req, res) => {
    try {
        const periods = await Test.distinct('period');
        res.json(periods.filter(p => p)); // Remove empty periods
    } catch (err) {
        console.error("❌ Error fetching available periods:", err);
        res.status(500).json({ message: "Server error" });
    }
});

export default router;