// updated file - routes/api/tests.js
import express from "express";
import mongoose from "mongoose";
import Test from "../../models/Test.js";
import StudentTestAttempt from "../../models/StudentTestAttempt.js";

const router = express.Router();

// Helper: compute maximum possible points for `howMany` questions (take top-N question points)
function maxPointsForHowMany(questions = [], howMany = 0) {
  const points = (questions || []).map(q => Number(q.points || 0)).sort((a,b) => b - a);
  return points.slice(0, howMany).reduce((s, p) => s + p, 0);
}

function normalizeQuestions(questions = []) {
  return questions.map(q => {
    // Create a fresh object for each question
    const question = {
      text: q.text || "",
      type: q.type || "identification",
      points: Number(q.points || 0),
      choices: [],
      answers: [],
      files: [],
      correctAnswer: undefined,
      feedbackWhenCorrect: q.feedbackWhenCorrect || {},
      feedbackWhenIncorrect: q.feedbackWhenIncorrect || {}
    };

    // Multiple choice
    if (question.type === "multiple") {
      question.choices = Array.isArray(q.choices) ? [...q.choices] : (q.choices ? [q.choices] : []);
      if (Array.isArray(q.correctAnswer)) {
        question.correctAnswer = [...q.correctAnswer];
      } else if (q.correctAnswer === undefined || q.correctAnswer === null || q.correctAnswer === "") {
        question.correctAnswer = [];
      } else {
        question.correctAnswer = [String(q.correctAnswer)];
      }
      question.answers = Array.isArray(q.answers) ? [...q.answers] : [];
    }

    // True/False, Identification, Enumeration, Essay
    else if (["truefalse", "identification", "enumeration", "essay"].includes(question.type)) {
      question.correctAnswer = Array.isArray(q.correctAnswer)
        ? (q.correctAnswer.length ? String(q.correctAnswer[0]) : "")
        : (q.correctAnswer ? String(q.correctAnswer) : "");
      question.answers = Array.isArray(q.answers) ? [...q.answers] : [];
    }

    // Attach files safely
    question.files = Array.isArray(q.files) ? [...q.files] : [];

    return question;
  });
}

// Helper: calculate student's score with debug logging and partial credit
function calculateScore(questions = [], studentAnswers = {}) {
  let totalEarned = 0;
  let totalPossible = 0;

  // Debug: Log input data
  console.log('🎯 SCORING DEBUG - START ======================');
  console.log('📝 Student Answers Received:', studentAnswers);
  console.log('❓ Questions to Score:', questions.map(q => ({
    id: q._id,
    type: q.type,
    text: q.text?.substring(0, 50) + '...',
    points: q.points,
    correctAnswer: q.correctAnswer,
    answers: q.answers
  })));

  questions.forEach(q => {
    const maxPts = Number(q.points || 0);
    totalPossible += maxPts;

    let earned = 0;

    // Debug per question
    console.log(`\n🔍 Scoring Question: ${q._id}`);
    console.log(`   Type: ${q.type}, Points: ${maxPts}`);
    console.log(`   Student Answer:`, studentAnswers[q._id]);
    console.log(`   Correct Answer:`, q.correctAnswer);
    console.log(`   Answers Array:`, q.answers);

    if (q.type === "multiple") {
      const correct = q.correctAnswer || [];
      const answer = Array.isArray(studentAnswers[q._id]) ? studentAnswers[q._id].map(String) : [];
      earned = answer.length && answer.every(a => correct.includes(a)) ? maxPts : 0;
      console.log(`   Multiple Choice - Earned: ${earned}/${maxPts}`);
      
    } else if (q.type === "truefalse") {
      const correct = String(q.correctAnswer || "").toLowerCase();
      const answer = String(studentAnswers[q._id] || "").toLowerCase();
      earned = (correct && correct === answer) ? maxPts : 0;
      console.log(`   True/False - Earned: ${earned}/${maxPts}, Correct: ${correct}, Student: ${answer}`);
      
    } else if (q.type === "identification") {
      const correct = String(q.correctAnswer || "").toLowerCase();
      const answer = String(studentAnswers[q._id] || "").toLowerCase();
      earned = (correct && correct === answer) ? maxPts : 0;
      console.log(`   Identification - Earned: ${earned}/${maxPts}, Correct: ${correct}, Student: ${answer}`);
      
    } else if (q.type === "enumeration") {
      // ENUMERATION WITH PARTIAL CREDIT AND DEBUG
      const correctAnswers = Array.isArray(q.answers) ? 
        q.answers.map(a => String(a).toLowerCase().trim()).filter(a => a) : [];
      const studentAnswer = studentAnswers[q._id];
      
      console.log(`   Enumeration Debug:`);
      console.log(`     Correct Answers:`, correctAnswers);
      console.log(`     Raw Student Answer:`, studentAnswer);
      
      // Convert student answer to array and normalize
      let studentAnswersArray = [];
      if (Array.isArray(studentAnswer)) {
        studentAnswersArray = studentAnswer.map(a => String(a).toLowerCase().trim()).filter(a => a);
      } else if (typeof studentAnswer === 'string') {
        studentAnswersArray = studentAnswer.split(/[,|\n]/).map(a => a.trim().toLowerCase()).filter(a => a);
      }
      
      console.log(`     Processed Student Answers:`, studentAnswersArray);
      
      if (correctAnswers.length === 0) {
        console.log(`   ⚠️  No correct answers defined for enumeration`);
        earned = 0;
      } else {
        const correctSet = new Set(correctAnswers);
        const studentSet = new Set(studentAnswersArray);
        
        // Count how many correct answers the student provided
        const correctCount = [...studentSet].filter(answer => correctSet.has(answer)).length;
        const totalRequired = correctAnswers.length;
        
        console.log(`     Correct Count: ${correctCount}/${totalRequired}`);
        
        // OPTION 1: All-or-nothing scoring (strict)
        // earned = (correctCount === totalRequired) ? maxPts : 0;
        
        // OPTION 2: Partial credit (recommended)
        earned = (correctCount / totalRequired) * maxPts;
        
        // OPTION 3: Partial credit with minimum threshold (at least 50% correct)
        // earned = (correctCount >= Math.ceil(totalRequired / 2)) ? 
        //          (correctCount / totalRequired) * maxPts : 0;
        
        console.log(`   Enumeration - Earned: ${earned}/${maxPts}, Correct: ${correctCount}/${totalRequired}`);
      }
      
    } else if (q.type === "essay") {
      // Essays might be graded manually later
      earned = 0;
      console.log(`   Essay - Manual grading required, Earned: ${earned}/${maxPts}`);
    }

    totalEarned += earned;
    console.log(`   Running Total: ${totalEarned}/${totalPossible}`);
  });

  // Final debug summary
  console.log('\n📊 SCORING DEBUG - FINAL SUMMARY ==============');
  console.log(`🏆 Total Earned: ${totalEarned}`);
  console.log(`🎯 Total Possible: ${totalPossible}`);
  console.log(`📈 Percentage: ${totalPossible > 0 ? ((totalEarned / totalPossible) * 100).toFixed(2) : 0}%`);
  console.log('🎯 SCORING DEBUG - END ========================\n');

  return { totalEarned, totalPossible };
}

// Create a test
router.post("/", async (req, res) => {
  try {
    const payload = req.body;
    if (!payload.title || !payload.subjectCode) {
      return res.status(400).json({ message: "title and subjectCode are required" });
    }

    const questions = Array.isArray(payload.questions) ? normalizeQuestions(payload.questions) : [];
    const totalQuestions = questions.length;
    const howManyQuestions = Number(payload.howManyQuestions || 0);

    if (howManyQuestions <= 0) return res.status(400).json({ message: "howManyQuestions must be greater than 0" });
    if (howManyQuestions > totalQuestions) return res.status(400).json({ message: "howManyQuestions cannot be more than total questions" });

    const maxPoints = maxPointsForHowMany(questions, howManyQuestions);
    const passingPoints = Number(payload.passingPoints || 0);
    if (passingPoints > maxPoints) return res.status(400).json({ message: `passingPoints cannot exceed maximum possible points (${maxPoints})` });

    const testDoc = new Test({
      title: payload.title,
      subjectCode: payload.subjectCode,
      description: payload.description || "",
      timeLimit: payload.timeLimit,
      deadline: payload.deadline ? new Date(payload.deadline) : undefined,
      access: payload.access || "Private",
      howManyQuestions,
      passingPoints,
      assignedSections: Array.isArray(payload.assignedSections) ? payload.assignedSections : [],
      prerequisites: Array.isArray(payload.prerequisites) ? payload.prerequisites : [],
      questions,
      createdBy: req.session?.user?.id,
    });

    await testDoc.save();
    res.status(201).json(testDoc);
  } catch (err) {
    console.error("❌ Error creating test:", err);
    res.status(500).json({ message: "Server error", error: err?.message || String(err) });
  }
});

// List tests (populate createdBy)
router.get("/", async (req, res) => {
  try {
    const tests = await Test.find()
      .populate("createdBy", "firstName middleName lastName email role") // 👈 populate creator info
      .sort({ createdAt: -1 })
      .lean({ virtuals: true });

    // Ensure totals (in case virtuals aren't included in lean)
    const withTotals = tests.map(t => ({
      ...t,
      totalQuestions: (t.questions || []).length,
      totalPoints: (t.questions || []).reduce((s, q) => s + (q.points || 0), 0),
    }));

    res.json(withTotals);
  } catch (err) {
    console.error("❌ Error listing tests:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// Get single test
router.get("/:id", async (req, res) => {
  try {
    const t = await Test.findById(req.params.id)
    .populate("createdBy", "fullName email role")
    .lean({ virtuals: true });

    if (!t) return res.status(404).json({ message: "Test not found" });
    res.json(t);
  } catch (err) {
    console.error("❌ Error getting test:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// Update test
router.put("/:id", async (req, res) => {
  try {
    const payload = req.body;
    const questions = Array.isArray(payload.questions) ? normalizeQuestions(payload.questions) : [];
    const totalQuestions = questions.length;
    const howManyQuestions = Number(payload.howManyQuestions || 0);

    if (howManyQuestions <= 0) {
      return res.status(400).json({ message: "howManyQuestions must be greater than 0" });
    }
    if (howManyQuestions > totalQuestions) {
      return res.status(400).json({ message: "howManyQuestions cannot be more than total questions" });
    }

    const maxPoints = maxPointsForHowMany(questions, howManyQuestions);
    const passingPoints = Number(payload.passingPoints || 0);
    if (passingPoints > maxPoints) {
      return res.status(400).json({ message: `passingPoints cannot exceed maximum possible points (${maxPoints}) for howManyQuestions=${howManyQuestions}` });
    }

    const updated = await Test.findByIdAndUpdate(req.params.id, {
      title: payload.title,
      subjectCode: payload.subjectCode,
      description: payload.description || "",
      timeLimit: payload.timeLimit,
      deadline: payload.deadline ? new Date(payload.deadline) : undefined,
      access: payload.access || "Private",
      howManyQuestions: howManyQuestions,
      passingPoints: passingPoints,
      assignedSections: Array.isArray(payload.assignedSections) ? payload.assignedSections : [],
      prerequisites: Array.isArray(payload.prerequisites) ? payload.prerequisites : [],
      questions,
      updatedAt: new Date()
    }, { new: true });

    if (!updated) return res.status(404).json({ message: "Test not found" });
    res.json(updated);
  } catch (err) {
    console.error("❌ Error updating test:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// Delete test
router.delete("/:id", async (req, res) => {
  try {
    const removed = await Test.findByIdAndDelete(req.params.id);
    if (!removed) return res.status(404).json({ message: "Test not found" });
    res.json({ message: "Deleted" });
  } catch (err) {
    console.error("❌ Error deleting test:", err);
    res.status(500).json({ message: "Server error" });
  }
});

/**
 * Check eligibility for a student to take a test based on prerequisites.
 *
 * POST /api/:id/check-eligibility
 * Body options:
 *  - { studentId: "<studentObjectId>" }
 *    Server will look up StudentTestAttempt documents for that student.
 *  - { completedTests: [{ testId: "<id>", passed: true|false, score?: number }, ...] }
 *    Use this to check client-side known completions without server attempts.
 *
 * Response:
 *  - { eligible: true }
 *  - { eligible: false, missing: ["<prereqTestId>", ...] }
 */
router.post("/:id/check-eligibility", async (req, res) => {
  try {
    const testId = req.params.id;
    const t = await Test.findById(testId).lean();
    if (!t) return res.status(404).json({ message: "Test not found" });

    const prereqs = Array.isArray(t.prerequisites) ? t.prerequisites.map(String) : [];

    if (prereqs.length === 0) {
      return res.json({ eligible: true });
    }

    // Gather passed prerequisites based on provided data
    let passedSet = new Set();

    // Option A: client provided completedTests array
    if (Array.isArray(req.body.completedTests)) {
      req.body.completedTests.forEach(ct => {
        if (ct && (ct.passed === true || ct.passed === "true")) {
          passedSet.add(String(ct.testId));
        } else if (typeof ct.score === "number" && ct.score >= 0 && ct.pass === true) { // legacy
          passedSet.add(String(ct.testId));
        }
      });
    }

    // Option B: server-side lookup by studentId
    if (req.body.studentId) {
      try {
        const attempts = await StudentTestAttempt.find({
          student: req.body.studentId,
          test: { $in: prereqs }
        }).lean();

        attempts.forEach(a => {
          if (a.passed) passedSet.add(String(a.test));
        });
      } catch (err) {
        console.warn("⚠️ Warning while looking up attempts for studentId:", err);
      }
    }

    // Determine missing prerequisites
    const missing = prereqs.filter(p => !passedSet.has(String(p)));

    if (missing.length === 0) {
      return res.json({ eligible: true });
    }

    return res.json({ eligible: false, missing });
  } catch (err) {
    console.error("❌ Error checking eligibility:", err);
    res.status(500).json({ message: "Server error" });
  }
});

export default router;