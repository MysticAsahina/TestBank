import express from "express";
import multer from "multer";
import { uploadToCloudinary } from "./cloudinary.js";

const router = express.Router();

// Configure multer for memory storage (files are processed and uploaded to Cloudinary)
const storage = multer.memoryStorage();
const upload = multer({ 
  storage,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  }
});

// Generic upload handler for Cloudinary
const uploadToCloudinaryHandler = async (req, res, folder = 'testbank') => {
  try {
    if (!req.file) {
      console.log('❌ No file received in upload request');
      return res.status(400).json({ message: "No file uploaded" });
    }

    console.log('📤 Uploading file to Cloudinary:');
    console.log('   File name:', req.file.originalname);
    console.log('   File size:', req.file.size);
    console.log('   MIME type:', req.file.mimetype);
    console.log('   Folder:', folder);

    const result = await uploadToCloudinary(req.file.buffer, folder);
    
    console.log('✅ Cloudinary upload successful:');
    console.log('   URL:', result.secure_url);
    console.log('   Public ID:', result.public_id);
    console.log('   Format:', result.format);
    console.log('   Bytes:', result.bytes);
    
    res.json({ 
      url: result.secure_url,
      publicId: result.public_id,
      format: result.format,
      bytes: result.bytes
    });
  } catch (error) {
    console.error("❌ Cloudinary upload error:", error);
    res.status(500).json({ message: "Failed to upload file to cloud storage: " + error.message });
  }
};

// File upload endpoints with Cloudinary
router.post("/upload", upload.single("file"), (req, res) => {
  uploadToCloudinaryHandler(req, res, 'testbank/general');
});

router.post("/uploads", upload.array("files"), async (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ message: "No files uploaded" });
    }

    const uploadPromises = req.files.map(file => 
      uploadToCloudinary(file.buffer, 'testbank/general')
    );

    const results = await Promise.all(uploadPromises);
    const urls = results.map(result => ({
      url: result.secure_url,
      publicId: result.public_id
    }));

    res.json({ urls });
  } catch (error) {
    console.error("❌ Error uploading files to Cloudinary:", error);
    res.status(500).json({ message: "Failed to upload files" });
  }
});

// Specific upload endpoints with organized folders
router.post("/upload/question", upload.single("file"), (req, res) => {
  uploadToCloudinaryHandler(req, res, 'testbank/questions');
});

router.post("/upload/correct", upload.single("file"), (req, res) => {
  uploadToCloudinaryHandler(req, res, 'testbank/feedback/correct');
});

router.post("/upload/incorrect", upload.single("file"), (req, res) => {
  uploadToCloudinaryHandler(req, res, 'testbank/feedback/incorrect');
});

// Test cover image upload
router.post("/upload/cover", upload.single("file"), (req, res) => {
  uploadToCloudinaryHandler(req, res, 'testbank/covers');
});

export default router;